﻿namespace web_bcolegardiner.server.Models
{
    public class Newsletter
    {
        public required string Email { get; set; }
    }
}